fx_version 'cerulean'
game 'gta5'

description 'jm-peds'
version '1.0.0'

-- What to run
client_scripts {
     'client.lua'
}
   
-- Config
shared_scripts {
	'config.lua'
}

lua54 'yes'