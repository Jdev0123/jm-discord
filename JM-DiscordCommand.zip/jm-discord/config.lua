Config = {}

Config.Discord = {
     UseDiscord = true
 }
